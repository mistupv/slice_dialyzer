-module(e2).

-export([main/1]).

main(X)->
	f(X),
	g(X),
	i(X),
	h(X).
	
	
f(1)->a;
f(2)->b;
f(3)->c.

g(1)->a;
g(4)->b.

i(1)->a;
i(2)->b;
i(3)->c.

h(4)->c.