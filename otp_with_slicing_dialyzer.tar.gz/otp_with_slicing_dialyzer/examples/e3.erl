-module(e3).

-export([main/1]).

main(X)->
	case X of
	     1 -> case X of
	               2 -> a
	          end
	end.