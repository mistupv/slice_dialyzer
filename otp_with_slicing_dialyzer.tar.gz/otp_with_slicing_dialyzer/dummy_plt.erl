-module(dummy_plt).

-export([main/0]).

main() -> 42.
